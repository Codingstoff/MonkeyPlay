var PLAY = 1;
var END = 0;
var gameState = PLAY;
var monkey, monkey_running, monkey_stopping;
var banana, bananaImage, obstacle, obstacleImage
var FoodGroup, obstacleGroup
var score
var survivaltime

function preload() {


  monkey_running = loadAnimation("sprite_0.png", "sprite_1.png", "sprite_2.png", "sprite_3.png", "sprite_4.png", "sprite_5.png", "sprite_6.png", "sprite_7.png", "sprite_8.png")
  monkey_stopping = loadAnimation("sprite_0.png")

  bananaImage = loadImage("banana.png");
  obstacleImage = loadImage("obstacle.png");

}



function setup() {

  createCanvas(600, 400);

  monkey = createSprite(60, 250, 50, 50);
  monkey.addAnimation("moving", monkey_running);
  monkey.addAnimation("stopping", monkey_stopping);
  monkey.scale = 0.12;

  ground = createSprite(500, 370, 900, 30);
  ground.velocityX = -5;
  ground.x = ground.width / 2;

  obstacleGroup = new Group();
  FoodGroup = new Group();

 score = 0;
  survivaltime = 0

}


function draw() {

  background("white");
  
  console.log(monkey.y);

 

  stroke("black");
  textSize(20);
  text("Score:" + score, 500, 50);
  
    stroke("black");
  textSize(20);
  text("Survival Time:" + survivaltime, 200, 50);

  if (gameState === PLAY) 
  {
    survivaltime = survivaltime + Math.round(getFrameRate()/60);
     
    if (ground.x < 150) 
    {

      ground.x = 300;
    }
      Spawnbanana();
      Spawnobstacles();

    if (keyDown("space") && monkey.y > 318) 
     {

      monkey.velocityY = -20;

     }

    monkey.velocityY = monkey.velocityY + 1.0
    
    if (monkey.isTouching(FoodGroup))
      {
        FoodGroup.destroyEach();
         score = score + 5;
      }
      
   if (obstacleGroup.isTouching(monkey))
     {
       gameState = END;
       
     }

  }
    else if (gameState === END)
       {
         
         obstacleGroup.setVelocityXEach(0);
         FoodGroup.setVelocityXEach(0);
         monkey.changeAnimation("stopping", monkey_stopping);
         ground.velocityX=0;
       }
 
         monkey.collide(ground);


         drawSprites();
}

function Spawnobstacles() {
  if (frameCount % 100 === 0) {
    var obstacle = createSprite(650, 340, 50, 50);
    obstacle.addImage(obstacleImage);
    obstacle.velocityX = -5;
    obstacle.setLifetime = 400;
    obstacle.scale = 0.1;

    obstacleGroup.add(obstacle);
  }
}

function Spawnbanana()
{
  
  if (frameCount % 80 === 0) 
  {
    var banana = createSprite(650,320,50,50)
    banana.addImage( bananaImage);
    banana.velocityX = -5;
    banana.setLifetime = 400;
    banana.scale = 0.1;
    
    banana.y = Math.round(random(120,200));
    
    FoodGroup.add(banana);
  }
}



